<?php
$monedas = [
    "libras" => 1.31,
    "euros"  => 1.09,
    "dolares" => 1
];
$cantidad = isset($_POST['cantidad']) ? $_POST['cantidad'] : '';
$origen   = isset($_POST['origen']) ? $_POST['origen'] : 'libras';
$destino  = isset($_POST['destino']) ? $_POST['destino'] : 'dolares';

$resultado = '';
$error = '';
$mostrar_resultado = false;

// Validación básica segun la teoria del PDF
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!is_numeric($cantidad) || $cantidad <= 0) {
        $error = "Por favor, introduce una cantidad válida mayor que cero.";
    } elseif (!isset($monedas[$origen]) || !isset($monedas[$destino])) {
        $error = "Selecciona monedas válidas.";
    } else {
        $resultado = ($cantidad * $monedas[$origen] / $monedas[$destino]. 2);
        $mostrar_resultado = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Conversor de monedas</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f8f8f8; }
        .container { background: #fff; margin: 50px auto; width: 430px; border-radius:8px; box-shadow:0 3px 12px #0002; padding: 24px; }
        .barra-azul { background:#2196F3; color:#fff; font-weight: bold; padding:10px 14px; margin: -24px -24px 18px -24px; border-radius:8px 8px 0 0;}
        .form-group { margin-bottom:14px; }
        label { font-weight:bold; display:inline-block; width:78px; }
        input[type="text"], select { width:200px; padding:6px 10px; border:1px solid #ccd; border-radius:4px; margin-left:4px;}
        .boton { display:block; width:110px; background: #4CAF50; color:#fff; font-size: 1.1em; font-weight: bold; border: none; border-radius: 4px; padding:8px; margin: 0 auto;}
        .error { color: #b00; background:#fee; padding: 5px; border-radius:4px; margin-bottom: 10px;}
    </style>
</head>
<body>
    <div class="container">
        <?php if ($mostrar_resultado): ?>
            <div class="barra-azul">
                <?php echo ($cantidad).' '.($origen).' son '.$resultado.' '.($destino); ?>
            </div>
        <?php endif; ?>

        <h2>Conversor de monedas</h2>
        <?php if ($error): ?>
            <div class="error"><?php echo ($error); ?></div>
        <?php endif; ?>
        <form method="post" action="">
            <div class="form-group">
                <label for="cantidad">Cantidad:</label>
                <input type="text" name="cantidad" id="cantidad" value="<?php echo ($cantidad); ?>">
            </div>
            <div class="form-group">
                <label for="origen">Origen:</label>
                <select name="origen" id="origen">
                    <?php foreach ($monedas as $codigo => $valor): ?>
                        <option value="<?php echo ($codigo); ?>" <?php if($codigo == $origen) echo 'selected'; ?>>
                            <?php echo ($codigo); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="destino">Destino:</label>
                <select name="destino" id="destino">
                    <?php foreach ($monedas as $codigo => $valor): ?>
                        <option value="<?php echo ($codigo); ?>" <?php if($codigo == $destino) echo 'selected'; ?>>
                            <?php echo ($codigo); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="boton">Convertir</button>
        </form>
    </div>
</body>
</html>



